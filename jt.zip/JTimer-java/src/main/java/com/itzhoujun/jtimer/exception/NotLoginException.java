package com.itzhoujun.jtimer.exception;

public class NotLoginException extends RuntimeException {
}
