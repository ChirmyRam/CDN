package com.itzhoujun.jtimer.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.itzhoujun.jtimer.entity.CronTaskLog;

public interface CronTaskLogMapper extends BaseMapper<CronTaskLog> {
}
