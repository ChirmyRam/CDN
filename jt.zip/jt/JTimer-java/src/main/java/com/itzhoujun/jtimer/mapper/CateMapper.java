package com.itzhoujun.jtimer.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.itzhoujun.jtimer.entity.Cate;

public interface CateMapper extends BaseMapper<Cate> {
}
